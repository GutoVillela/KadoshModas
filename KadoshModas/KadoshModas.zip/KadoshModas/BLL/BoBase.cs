﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KadoshModas.BLL
{
    /// <summary>
    /// Classe BLL base para outras classes BLL. Esta classe contém atributos em comum entre todas as classes BLL
    /// </summary>
    class BoBase
    {
    }
}
